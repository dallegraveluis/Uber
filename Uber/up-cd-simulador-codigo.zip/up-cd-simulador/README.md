# Up CD · rollout por tiers

Simulador do deploy contínuo da Uber com rollout por tiers de criticidade.

## Como rodar

Abra `index.html` em qualquer navegador (dois cliques). Não precisa instalar nada nem de servidor.

## Estrutura

```
up-cd-simulador/
├── index.html        estrutura da página
├── css/style.css     visual (cores, layout, animações)
├── js/script.js      lógica da simulação
└── img/
    ├── pelicano.jpg  logo
    └── favicon.png   ícone da aba
```

## Tecnologias

- HTML, CSS e JavaScript puros, sem framework e sem biblioteca externa
- Fontes Archivo e JetBrains Mono, do Google Fonts (carregadas pela internet;
  sem internet, o navegador usa as fontes padrão e o resto funciona igual)

## Como a lógica funciona (js/script.js)

- `front()`: etapas Commit → Kafka → Bazel do pipeline
- `checks()`: o gate conferindo tempo mínimo, janela de deploy e alertas
- `small()`, `elevator()`, `big()`: os quatro cenários
- `avaliarTier()`: o job central; devolve `ESPERAR`, `LIBERAR_PROXIMO` ou `COMMIT_ISSUE`
  a partir da taxa de sucesso e da taxa de erro do tier

## Cenários

- **Commit pequeno:** só um serviço muda e passa pelos gates.
- **Gate fechado:** os commits A, B e C esperam; o gate leva só o C.
- **Commit grande:** rollout do tier 5 ao tier 0.
- **Commit com bug:** o tier 5 falha, rollback, commit issue; tiers 4 a 0 protegidos.
