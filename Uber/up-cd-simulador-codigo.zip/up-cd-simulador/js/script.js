// Simulador do Up CD com rollout por tiers
(() => {
const STAGES=[['Commit','no main'],['Kafka','fila de eventos'],['Bazel','quem mudou?'],['Build','imagem'],['Gates','pode seguir?'],['Produção','deploy']];
const TIERS=[[5,18],[4,15],[3,12],[2,10],[1,8],[0,6]];
const $=id=>document.getElementById(id);
let svcs=[],tiers=[],run=0,t0=0,thr=.8,errLim=.2,spd=1;

function build(){
  $('pipe').innerHTML=STAGES.map((s,i)=>`<div class="st" id="st${i}"><b>${s[0]}</b><span>${s[1]}</span></div>`).join('');
  svcs=[];tiers=TIERS.map(([t,n])=>{const ids=[];for(let i=0;i<n;i++){ids.push(svcs.length);svcs.push({tier:t,st:''});}return{t,n,ids,ok:0,fail:0}});
  svcs[tiers[4].ids[0]].pay=true;
  $('fleet').innerHTML=tiers.map((T,k)=>`<div class="tier" id="tr${k}"><h3>Tier ${T.t}</h3><div class="s" id="ts${k}">${T.t==5?'menos crítico':T.t==0?'mais crítico':''}</div><div class="dots">${T.ids.map(i=>`<i class="d${svcs[i].pay?' star':''}" id="d${i}" title="${svcs[i].pay?'pagamentos':'serviço '+i}"></i>`).join('')}</div><div class="meter"><i id="m${k}"></i><u style="left:${thr*100}%"></u></div></div>`).join('');
  $('gate').innerHTML='';$('issue').className='issue';$('issue').textContent='';$('log').innerHTML='';
}
const dot=(i,c)=>{svcs[i].st=c;const e=$('d'+i);e.className='d'+(c?' '+c:'')+(svcs[i].pay?' star':'')};
const stage=(i,c)=>{$('st'+i).className='st'+(c?' '+c:'')};
const tier=(k,c,txt)=>{if(c!==null)$('tr'+k).className='tier'+(c?' '+c:'');if(txt!=null)$('ts'+k).textContent=txt};
const meter=k=>{$('m'+k).style.width=(tiers[k].ok/tiers[k].n*100)+'%'};
function log(msg,c=''){const s=((performance.now()-t0)/1000*spd).toFixed(1).padStart(5,'0');const p=document.createElement('div');p.innerHTML=`<span class="t">[${s}s]</span> `;const m=document.createElement('span');m.className=c;m.textContent=msg;p.appendChild(m);$('log').appendChild(p);$('log').scrollTop=1e9}
function w(ms,id){return new Promise((r,j)=>setTimeout(()=>id===run?r():j('stop'),ms/spd))}
function start(){run++;build();t0=performance.now();return run}
async function front(id,msg,bz){
  log(msg);stage(0,'on');await w(700,id);stage(0,'ok');
  stage(1,'on');log('evento publicado no Kafka: acorda o sistema de deploy');await w(900,id);stage(1,'ok');
  stage(2,'on');await w(900,id);log(bz);stage(2,'ok');
}
async function checks(id,list){
  $('gate').innerHTML=list.map((c,i)=>`<span class="c" id="g${i}">${c}: …</span>`).join('');
  for(let i=0;i<list.length;i++){await w(500,id);const e=$('g'+i);e.className='c ok';e.textContent=list[i]+': ok'}
}
const CH=['tempo mínimo','janela de deploy','sem alertas'];

async function small(id){
  const p=tiers[4].ids[0];
  await front(id,'commit a1f3: altera só o serviço de pagamentos','Bazel: 1 serviço afetado (pagamentos)');
  dot(p,'wait');stage(3,'on');await w(900,id);log('build: imagem pagamentos:a1f3 gerada');stage(3,'ok');
  stage(4,'on');await checks(id,CH);log('gate aberto: pode seguir');stage(4,'ok');
  stage(5,'on');dot(p,'run');await w(1200,id);dot(p,'ok');stage(5,'ok');
  log('deploy concluído em produção, sem ninguém apertar botão','g');
}
async function elevator(id){
  const p=tiers[4].ids[0];
  await front(id,'commit A: altera pagamentos','Bazel: 1 serviço afetado (pagamentos)');
  dot(p,'wait');stage(3,'on');await w(700,id);stage(3,'ok');stage(4,'wait');
  $('gate').innerHTML='<span class="c no">janela de deploy: fechada</span> <span class="chip" id="cA">A</span>';
  log('gate fechado (fora do horário do time): A espera','w');await w(1600,id);
  log('commit B chega (mesmo serviço) e espera');$('gate').insertAdjacentHTML('beforeend',' <span class="chip" id="cB">B</span>');await w(1400,id);
  log('commit C chega e espera');$('gate').insertAdjacentHTML('beforeend',' <span class="chip" id="cC">C</span>');await w(1600,id);
  $('gate').querySelector('.c').className='c ok';$('gate').querySelector('.c').textContent='janela de deploy: aberta';
  log('janela abriu: o gate leva só o commit mais novo pronto (C)');$('cA').className='chip skip';$('cB').className='chip skip';$('cC').className='chip go';
  stage(4,'ok');stage(5,'on');dot(p,'run');await w(1200,id);dot(p,'ok');stage(5,'ok');
  log('A e B pulados: C já contém as mudanças deles');log('resultado: 1 deploy em vez de 3','g');
}
function avaliarTier(T){
  const feitos=T.ok+T.fail,taxa=T.fail/Math.max(feitos,1);
  if(feitos>=5&&taxa>errLim)return'COMMIT_ISSUE';
  if(T.ok/T.n>=thr)return'LIBERAR_PROXIMO';
  if(feitos===T.n)return'COMMIT_ISSUE';
  return'ESPERAR';
}
async function big(id,bug){
  const hash=bug?'9e2c':'7b10';
  await front(id,bug?'commit 9e2c: atualiza a lib de RPC (com um bug que os testes não pegaram)':'commit 7b10: atualiza a lib de RPC usada por quase todo serviço Go',`Bazel: ${svcs.length} serviços afetados (na Uber, ~3.000)`);
  svcs.forEach((_,i)=>dot(i,'wait'));tiers.forEach((_,k)=>tier(k,'','aguardando'));
  stage(3,'on');await w(900,id);log(`build: ${svcs.length} imagens geradas`);stage(3,'ok');
  stage(4,'on');$('gate').innerHTML='<span class="c">orquestração por tiers: job central acompanha o estado do commit</span>';
  for(let k=0;k<tiers.length;k++){
    const T=tiers[k];let halted=false;
    tier(k,'lib','liberado');log(`estado: tier ${T.t} liberado`);
    T.ids.forEach(i=>{(async()=>{await w(250+Math.random()*1700,id);if(halted)return;dot(i,'run');await w(600+Math.random()*900,id);if(halted){dot(i,'');return}
      const f=bug?Math.random()<.35:false;
      if(f){T.fail++;dot(i,'fail');await w(500,id);dot(i,'rb');if(!halted)log(`serviço ${i} falhou (container não sobe / SLA): rollback automático`,'w')}else{T.ok++;dot(i,'ok')}
      meter(k);tier(k,null,`${T.ok}/${T.n} ok${T.fail?` · ${T.fail} falha(s)`:''}`)})().catch(()=>{})});
    let r='ESPERAR';
    while(r==='ESPERAR'){await w(150,id);r=avaliarTier(T)}
    if(r==='COMMIT_ISSUE'){
      halted=true;await w(300,id);
      T.ids.forEach(i=>{if(svcs[i].st==='wait'||svcs[i].st==='run')dot(i,'')});
      const taxa=Math.round(T.fail/(T.ok+T.fail)*100),okp=Math.round(T.ok/T.n*100);
      tier(k,'fail',`falhou: ${taxa}% de erro`);stage(4,'fail');
      if(T.fail/(T.ok+T.fail)>errLim)log(`taxa de erro no tier ${T.t}: ${taxa}% > limite ${Math.round(errLim*100)}%`,'e');
      else log(`tier ${T.t} terminou com só ${okp}% de sucesso, abaixo de ${Math.round(thr*100)}%`,'e');
      log(`commit issue aberta para ${hash}: bloqueado até incluir a correção`,'e');
      log('autor notificado na hora','e');
      for(let j=k+1;j<tiers.length;j++){tier(j,'prot','protegido');tiers[j].ids.forEach(i=>dot(i,'prot'))}
      const resto=k<tiers.length-1?(tiers[k+1].t===0?'O tier 0 nunca recebeu':`Os tiers ${tiers[k+1].t} a 0 nunca receberam`):'';
      $('issue').textContent=`Commit issue: ${hash} bloqueado no tier ${T.t}. `+(resto?resto+' o commit ruim.':'');$('issue').className='issue show';
      if(resto)log(resto.toLowerCase()+' a mudança','g');return;
    }
    log(`tier ${T.t}: ${Math.round(T.ok/T.n*100)}% ok ≥ ${Math.round(thr*100)}%`+(k<tiers.length-1?', libera o próximo':''),'g');
    if(k<tiers.length-1)await w(400,id);
  }
  await w(2200,id);tiers.forEach((T,k)=>tier(k,'done',`${T.ok}/${T.n} ok`));stage(4,'ok');stage(5,'ok');
  const nf=tiers.reduce((a,T)=>a+T.fail,0);
  if(nf){tiers.forEach((T,k)=>tier(k,T.fail?'fail':'done',`${T.ok}/${T.n} ok · ${T.fail} falha(s)`));log(`rollout concluído, mas ${nf} serviços receberam o bug em todos os tiers: os limites estavam frouxos demais`,'e')}
  else log('rollout concluído: todos os tiers liberados, do menos ao mais crítico','g');
}
const go=f=>()=>{const id=start();f(id).catch(()=>{})};
$('b1').onclick=go(small);$('b2').onclick=go(elevator);$('b3').onclick=go(id=>big(id,false));$('b4').onclick=go(id=>big(id,true));
$('rs').onclick=()=>{run++;build()};
$('kThr').oninput=e=>{thr=e.target.value/100;$('vThr').textContent=e.target.value+'%';document.querySelectorAll('.meter u').forEach(u=>u.style.left=e.target.value+'%')};
$('kErr').oninput=e=>{errLim=e.target.value/100;$('vErr').textContent=e.target.value+'%'};
$('kSpd').oninput=e=>{spd=+e.target.value;$('vSpd').textContent=e.target.value+'×'};
build();log('aguardando commit...');
})();
